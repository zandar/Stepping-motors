/*****************************************************
This program was produced by the
CodeWizardAVR V2.03.8a Evaluation
Automatic Program Generator
� Copyright 1998-2008 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : Krokove motory
Version : 1.0
Date    : 20.11.2008
Author  : Michal Vokac
Company : Student CVUT FEL
Comments: 
Firmware pro ridici desku ovladajici sestavu krokovych motoru.


Chip type           : ATmega8
Program type        : Application
Clock frequency     : 8,000000 MHz
Memory model        : Small
External RAM size   : 0
Data Stack size     : 256
*****************************************************/

#include <mega8.h>
#include <stdlib.h>
#include <stdio.h>
#include <delay.h>
#include "RizeniFunkce.c"

#define RXB8 1
#define TXB8 0
#define UPE 2
#define OVR 3
#define FE 4
#define UDRE 5
#define RXC 7

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)  

    
unsigned int reciveCnt = 0; // citac poctu prijatych bajtu
char reciveData[7];     // pole pro ulozeni poslanych bajtu
char crc = 0;   // kontrolni soucet komunikace
char rotate = 0;
extern volatile struct rotation; // struktura obsahujci dekodovana prijata data 

// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
    // zastavit otaceni motorem-vynulovat vsechny promenne souvisejci s otacenim
    rotation.steps = 0;
}

// preruseni od seriove linky
interrupt [USART_RXC] void usart_int(void)
{
    // pokud jde o prvni preruseni
    if(reciveCnt == 0)
    {
        // precte jeden byte z UART
        reciveData[0] = getchar();
        // pokud se jedna o hlavicku komunikace, inkrementuje citac poctu bajtu
        if(reciveData[0] == 'H')
        {
            reciveCnt++;
            return;
        }
        // pokud je hlavicka spatna, vynuluje promenne a vrati se 
        reciveCnt = 0;
        reciveData[0] = 0;
        return;
    }
    else    // pri dalsich prerusenich
    {
        // pokud prislo posledni preruseni
        if(reciveCnt == 6)
        {
            int i = 0;  // promenna pro iteraci ve for cyklu
            // prijme posledni bajt
            reciveData[6] = getchar();
            crc = 0;
            // provede kontrolni soucet vsech bajtu
            for(;i<6;i++)
            {
                crc += reciveData[i];
            }
            
            // pokud je kontrola OK, provest otaceni motorem a vratit informaci o poloze kotouce
            if(crc == reciveData[6])
            {
                // otacet motorem
                putsf("OK");
                rotate = 1; // nastavi priznak pro otaceni
                
            }
            else  // pokud kontrola neni OK, vrati info o chybe komunikace
            {
                putsf("ER");
                rotate = 0;         
            }
            reciveCnt = 0;
            reciveData[0] = 0;
            return;  
        }
        
        // prijme dalsi bajt z UART a inkrementuje citac preruseni
        reciveData[reciveCnt] = getchar();
        reciveCnt++;    
    }
}


// Get a character from the USART Receiver
#ifndef _DEBUG_TERMINAL_IO_
#define _ALTERNATE_GETCHAR_
#pragma used+
char getchar(void)
{
char status;
char data;

while (1)
      {
      while (((status=UCSRA) & RX_COMPLETE)==0);
      data=UDR;
      if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
         return data;
      };
}
#pragma used-
#endif

// Write a character to the USART Transmitter
#ifndef _DEBUG_TERMINAL_IO_
#define _ALTERNATE_PUTCHAR_
#pragma used+
void putchar(char c)
{
while ((UCSRA & DATA_REGISTER_EMPTY)==0);
UDR=c;
}
#pragma used-
#endif


//-------------------------------------------------------------
// METODA MAIN 
//-------------------------------------------------------------

void main(void)
{

// Input/Output Ports initialization
// Port B initialization
// PB7=In
// PB6=In
// PB5=Out - MOTOR 3 , smer otaceni
// PB4=Out - MOTOR 3 , krokovaci impulsy
// PB3=In  - MOTOR 3 , optozavora
// PB2=Out - MOTOR 4 , smer otaceni
// PB1=Out - MOTOR 4 , krokovaci impulsy
// PB0=In  - MOTOR 4 , optozavora
// State7=T State6=T State5=0 State4=0 State3=T State2=0 State1=0 State0=T 
PORTB=0x00;
DDRB=0x36;

// Port C initialization
// PC6=In  - RESET 
// PC5=Out - MOTOR 1 , smer otaceni
// PC4=Out - MOTOR 1 , krokovaci impulsy
// PC3=In  - MOTOR 1 , optozavora
// PC2=Out - MOTOR 2 , smer otaceni
// PC1=Out - MOTOR 2 , krokovaci impulsy
// PC0=In  - MOTOR 2 , optozavora
// State6=T State5=0 State4=0 State3=T State2=0 State1=0 State0=T 
PORTC=0x00;
DDRC=0x36;

// Port D initialization
// PD7=In
// PD6=In - FTDI DSR
// PD5=In - FTDI DCD
// PD4=In - FTDI CTS
// PD3=In - FTDI DTR
// PD2=In - FTDI RTS
// PD1=In - FTDI RxD
// PD0=In - TFDI TxD
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTD=0x00;
DDRD=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
TCCR0=0x00;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Normal top=FFFFh
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Rising Edge
// INT1: Off
GICR|=0x40;
MCUCR=0x03;
GIFR=0x40;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// USART initialization
// Communication Parameters: 8 Data, 2 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 9600
UCSRA=0x00;
UCSRB=0x98;
UCSRC=0x8E;
UBRRH=0x00;
UBRRL=0x33;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// Global enable interrupts
#asm("sei")

//-----------------------------------------------------------
// HLAVNI TELO PROGRAMU

for (;;)
    {
        // ceka v nekonecne smycce na preruseni ktere povoli vstup do tela 
        if(rotate)
        {
            decodeReciveData(); // vola metodu pro dekodovani prijatych dat
                
            switch(rotation.motorNumber)
            {
                case 0:
                    rotMotor1();
                    break;
                    
                case 1:
                    rotMotor2();    
                    break;
                    
                case 2:
                    rotMotor3();
                    break;
                    
                case 3:
                    rotMotor4();
                    break;
            }
            rotate = 0; // deaktivuje priznak otaceni
        }    
    };
}
