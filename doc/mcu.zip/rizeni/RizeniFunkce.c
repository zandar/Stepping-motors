volatile struct rotParameters
{
    char motorNumber;
    char direction;
    char rotType;
    unsigned int speed;
    unsigned int steps;        
} rotation;

extern char reciveData[];   // promenna obsahuje prijata data

//---------------------------------------------------------
// MOJE METODY
//---------------------------------------------------------

// metoda pro dekodovani prijatych dat, jejich ulozeni a volani metody pro otocei prislusnym motorem
void decodeReciveData()
{
    rotation.motorNumber = (reciveData[1] >> 6);        // ulozeni cisla ovladace
    rotation.direction = ((reciveData[1] & 0x3f)>> 5);  // ulozeni smeru otaceni
    rotation.rotType = ((reciveData[1] & 0x1f)>>4);     // ulozeni zpusobu otaceni
    rotation.speed = reciveData[3];                     // ulozeni horniho bajtu rychlosti
    rotation.speed = rotation.speed << 8;
    rotation.speed += reciveData[2];                    // ulozeni dolniho bajtu rychlosti
    rotation.steps = reciveData[5];                     // ulozeni horniho bajtu kroku/sektoru                     
    rotation.steps = rotation.steps << 8;
    rotation.steps += reciveData[4];                    // ulozeni dolniho bajtu kroku/sektoru
}

// metoda pro otaceni motorem 1
void rotMotor1()
    {   
        unsigned int i;
        PORTC.5 = rotation.direction;
        
        for(i = 0;i < rotation.steps;i++)
        {
            PORTC.4 = 1;
            delay_ms(2);
            PORTC.4 = 0;
            delay_ms(rotation.speed);
        }
    }
    
// metoda pro otaceni motorem 2
void rotMotor2()
    {   
        unsigned int i;
        PORTC.2 = rotation.direction;
        
        for(i = 0;i < rotation.steps;i++)
        {
            PORTC.1 = 1;
            delay_ms(1);
            PORTC.1 = 0;
            delay_ms(rotation.speed);
        }
    }
    
// metoda pro otaceni motorem 3
void rotMotor3()
    {   
        unsigned int i;
        PORTB.5 = rotation.direction;
        
        for(i = 0;i < rotation.steps;i++)
        {
            PORTB.4 = 1;
            delay_ms(1);
            PORTB.4 = 0;
            delay_ms(rotation.speed);
        }
    }
    
// metoda pro otaceni motorem 4
void rotMotor4()
    {   
        unsigned int i;
        PORTB.2 = rotation.direction;
        
        for(i = 0;i < rotation.steps;i++)
        {
            PORTB.1 = 1;
            delay_ms(1);
            PORTB.1 = 0;
            delay_ms(rotation.speed);
        }
    }