/*****************************************************
This program was produced by the
CodeWizardAVR V2.03.8a Evaluation
Automatic Program Generator
� Copyright 1998-2008 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : Krokove motory
Version : 1.0
Date    : 20.11.2008
Author  : Michal Vokac
Company : Student CVUT FEL
Comments: 
Firmware pro desku budici jeden krokovy motor krokovych motoru. 

baf
Chip type           : ATtiny13
Clock frequency     : 9,600000 MHz
Memory model        : Tiny
External RAM size   : 0
Data Stack size     : 16
*****************************************************/

#include <tiny13.h>
#include <delay.h>

void toc();

// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
    toc();
}

unsigned int stav = 0;  // obsahuje cislo aktualniho kroku

// Metoda pro otoceni motoru o jeden krok, volana v preruseni INT 0
void toc()
{
    if(PINB.0 == 1) // volba smeru otaceni motoru, 0 = po smeru, 1 = proti smeru
    {   // otaceni proti smeru
        switch(stav+1)  // nastavi stav o jedna vetsi nez je aktualni
        {
            case 4: // prechod ze stavu 3 na stav 0
            case 0: 
                PORTB.3 = 1;
                PORTB.4 = 1;
                stav = 0;
                break;
            case 1:
                PORTB.3 = 1;
                PORTB.4 = 0;
                stav = 1;
                break;
            case 2:
                PORTB.3 = 0;
                PORTB.4 = 0;
                stav = 2;
                break;
            case 3:
                PORTB.3 = 0;
                PORTB.4 = 1;
                stav = 3;
                break;   
        }
    }
    else
    {   // otaceni po smeru
        switch(stav-1)  // nastavi stav o jedna mensi nez je aktualni
        {
            case 0: 
                PORTB.3 = 1;
                PORTB.4 = 1;
                stav=0;
                break;
            case 1:
                PORTB.3 = 1;
                PORTB.4 = 0;
                stav = 1;
                break;
            case 2:
                PORTB.3 = 0;
                PORTB.4 = 0;
                stav = 2;
                break;
            case -1:    // prechod ze stavu 0 do stavu 3
            case 3:
                PORTB.3 = 0;
                PORTB.4 = 1;
                stav = 3;
                break;
        }
    }
}

void main(void)
{ 
  //Crystal Oscillator division factor: 1
  #pragma optsize-
  CLKPR=0x80;
  CLKPR=0x00;
  #ifdef _OPTIMIZE_SIZE_
  #pragma optsize+
  #endif

  // Input/Output Ports initialization
  // Port B initialization
  // Func5=In Func4=Out Func3=Out Func2=In Func1=In Func0=In 
  // State5=T State4=0 State3=0 State2=T State1=T State0=T 
  PORTB=0x03;
  DDRB=0x1C;

  // Timer/Counter 0 initialization
  // Clock source: System Clock
  // Clock value: Timer 0 Stopped
  // Mode: Normal top=FFh
  // OC0A output: Disconnected
  // OC0B output: Disconnected
  TCCR0A=0x00;
  TCCR0B=0x00;
  TCNT0=0x00;
  OCR0A=0x00;
  OCR0B=0x00;

  // External Interrupt(s) initialization
  // INT0: On
  // INT0 Mode: Falling Edge
  // Interrupt on any change on pins PCINT0-5: Off
  GIMSK=0x40;
  MCUCR=0x00;
  GIFR=0x40;

  // Timer/Counter 0 Interrupt(s) initialization
  TIMSK0=0x00;

  // Analog Comparator initialization
  // Analog Comparator: Off
  ACSR=0x80;
  ADCSRB=0x00;

  // Global enable interrupts
  #asm("sei")
  PORTB.3 = 1;
  PORTB.4 = 1;
  stav = 0;

  while(1)
  {;
  //ceka ve smycce na preruseni krokovacim pulsem      
  };
}
